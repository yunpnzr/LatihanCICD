package com.example.latihancicd.domain

data class MessageEntity(
    var welcomeMessage: String
)